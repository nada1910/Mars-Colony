public class Fire extends Emergency {
    private boolean fireActive;
    private int severity;//1 for low 2 for moderate 3 for high
    private int oxygenConsumption;
    private Laboratory affectedLab;

    public Fire(boolean fireActive, int severity, int oxygenConsumption,Laboratory affectedLab, int id, EmergencyType type, FacilityType location, String description) {
        super(id, type, location, description);
          if (affectedLab == null) {
            throw new IllegalArgumentException("Invalid Habitat");
        }
        if (severity < 1 || severity > 3) {
            throw new IllegalArgumentException("Severity must be between 1 and 3");
        }
        if (oxygenConsumption < 0) {
            throw new IllegalArgumentException("Invalid oxygen consumption");
        }
        this.affectedLab=affectedLab;
        this.fireActive = fireActive;
        this.severity = severity;
        this.oxygenConsumption = oxygenConsumption;
    }

    public boolean isFireActive() { return fireActive; }
    public int getSeverity() { return severity; }

    public int getOxygenConsumption() {
        return oxygenConsumption;
    }

    public Laboratory getAffectedLab() {
        return affectedLab;
    }
    
    @Override
    public boolean hasRequiredResponders() {
       return !responders().isEmpty();
       
    }
    public boolean extinguishFire(){
        if(hasRequiredResponders()){
           fireActive=false;
           affectedLab.extinguish();
           System.out.println("Fire Extinguished");
           resolveEmergency();
           return true;
        }
        System.out.println("Fire Still Active");
        this.setStatus(EmergencyStatus.UNRESOLVED);
        
        
        return false;
    }
    public void consumeOxygen(){
        if(severity==1){
            affectedLab.consumeResource(ResourcesType.OXYGEN,5);
        }
        else if(severity==2){
            affectedLab.consumeResource(ResourcesType.OXYGEN,10);
        }
        else{
           affectedLab.consumeResource(ResourcesType.OXYGEN,15);
        }
     
        
    }
    public void setFire(){
        fireActive=true;
        affectedLab.setOperationalStatus(OperationalStatus.DAMAGED);
        affectedLab.setFire();
   
    }
    
        public void tick() {
    if (fireActive && getStatus() != EmergencyStatus.RESOLVED) {
        consumeOxygen();
    }
}
        
    @Override
    public void applyInitialEffect() { setFire(); }

    @Override
    public void resolve() { extinguishFire(); }

    @Override
    public Facility getAffectedFacility() { return affectedLab; }
    
    
}
